setwd("C:\\Users\\it24102889\\Desktop\\IT24102889")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = FALSE)
names(Delivery_Times) <- "Delivery_Time"
Delivery_Time <- as.numeric(Delivery_Times$Delivery_Time)
View(Delivery_Times)
attach(Delivery_Times)

histogram <- hist(Delivery_Time, 
                  main = "Histogram of Delivery Times", 
                  xlab = "Delivery Time (minutes)",
                  breaks = seq(20, 70, length = 10),
                  right = FALSE,
                  col = "lightblue")

breaks <- round(histogram$breaks)
freq <- histogram$counts
cum.freq <- cumsum(freq)
new <- c(0, cum.freq)

plot(breaks, new, 
     type = "l", 
     main = "Cumulative Frequency Polygon (Ogive) for Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency",
     col = "blue", 
     lwd = 2,
     ylim = c(0, max(new) + 5))

points(breaks, new, pch = 16, col = "red")
cbind(Upper_Limit = breaks, Cumulative_Frequency = new)

